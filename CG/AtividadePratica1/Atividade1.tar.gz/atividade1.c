#include "cg2d.h"

int desenha_linha_1(int x1, int y1, int x2, int y2, int cor, bufferdevice * monitor) { 

/*
 Esta função implementa o algoritmo de Bresenham de acordo com as equações
 apresentadas em sala de aula (veja slides no moodle) para um 
 coeficiente angular no intervalo [0,1].
 
 O algoritmo consiste em valiar o erro p = F(x,y), onde
 
 		F(x,y) = dy*x - dx*y + dx*b
 
 Considerando:
 
 Erro inicial: p = F(x+1,y+(1/2))
 
 Se p >= 0, modifica-se p = p + 2*dy - 2*dx e o próximo ponto será (x+1,y+1).
 O incremento 2*dy - 2*dx é determinado avaliando-se a função 2*F(x+1,y+1).
 
 Se p < 0, modifica-se p = p + 2*dy e o próximo ponto será (x+1,y).
 O incremento 2*dy é determinado avaliando-se a função 2*F(x+1,y).   
*/

  int x, y, dx, dy, p;

  dy = y2 - y1;
  dx = x2 - x1;
 
  x = x1;
  y = y1;
  p = 2*dy - dx;
  
  while ( (x <= x2) && (y <= y2) ) {
    if (p >= 0) {
      monitor->buffer[(monitor->MaxY - y) * monitor->MaxX + x] = cor;
      p = p + 2*dy - 2*dx;
      x = x + 1;
      y = y + 1; 
      }
    else {
      monitor->buffer[(monitor->MaxY - y) * monitor->MaxX + x] = cor;
      p = p + 2*dy;
      x = x + 1;
      }
    }
    
  return 0;
  }
  
int desenha_linha_2(int x1, int y1, int x2, int y2, int cor, bufferdevice * monitor) {

/*
 Esta função implementa o algoritmo de Bresenham de acordo com as equações
 apresentadas em sala de aula (veja slides no moodle) para um 
 coeficiente angular no intervalo [-1,0).
 
 O algoritmo consiste em valiar o erro p = F(x,y), onde
 
 		F(x,y) = dy*x - dx*y + dx*b
 
 Considerando:
 
 Erro inicial: p = F(x+1,y-(1/2))
 
 Se p <= 0, modifica-se p = p + incremento e o próximo ponto será (x+1,y-1).
 O incremento é determinado avaliando-se a função 2*F(x+1,y-1).
 
 Se p > 0, modifica-se p = p + incremento e o próximo ponto será (x+1,y).
 O incremento é determinado avaliando-se a função 2*F(x+1,y).   
*/

  printf("Implemente essa função!\n");    // É PARA TRABALHAR NESTE TRECHO!!!!!
    
  return 0;
  }

int main(int argc, char ** argv) {

  int x1, y1, x2, y2, cor;
  palette * palheta;
  bufferdevice * monitor;
  
  palheta = CreatePalette(2);
  SetColor(0,0,0,palheta);
  SetColor(1,1,1,palheta);
  
  monitor = CreateBuffer(600,600);

  // Teste primeiro com esses valores para a desenha_linha_1()
  x1 = 20; y1 = 20;
  x2 = 580; y2 = 570;

  // Depois, teste com esses valores para a desenha_linha_2()   
  //x1 = 20; y1 = 570;
  //x2 = 580; y2 = 20;  
  
  float a = (float) (y2-y1)/(x2-x1);
  cor = 1;
  
  printf("Coeficiente angular da reta: %f\n",a); 

  if ( (a >= 0) && (a <= 1) ) {
     printf("O coeficiente angular está no intervalo [0,1].\n");
     printf("Desenhando a linha.\n");
     desenha_linha_1(x1,y1,x2,y2,cor,monitor);
     Dump2X(monitor,palheta);
     }
  else { 
    if ( (a < 0) && (a >= -1) ) {
      printf("O coeficiente angular está no intervalo [-1,0).\n");
      printf("Desenhando a linha.\n");
      desenha_linha_2(x1,y1,x2,y2,cor,monitor);
      Dump2X(monitor,palheta);
      }
    else printf("O coeficiente angular não está nos intervalos [-1,0) ou [0,1].\n");
    }

  return 0;
  }


